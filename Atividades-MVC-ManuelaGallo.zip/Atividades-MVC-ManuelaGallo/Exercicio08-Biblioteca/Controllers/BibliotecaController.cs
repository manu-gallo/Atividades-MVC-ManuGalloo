using Microsoft.AspNetCore.Mvc;
using BibliotecaMVC.Models;
namespace BibliotecaMVC.Controllers;
public class BibliotecaController : Controller {
    private static readonly List<Livro> Itens = new() { new Livro { Id = 1, Titulo = "Dom Casmurro", Autor = "Machado de Assis", Ano = 1899, Disponivel = true },
new Livro { Id = 2, Titulo = "O Cortiço", Autor = "Aluísio Azevedo", Ano = 1890, Disponivel = false },
new Livro { Id = 3, Titulo = "Capitães da Areia", Autor = "Jorge Amado", Ano = 1937, Disponivel = true },
new Livro { Id = 4, Titulo = "Vidas Secas", Autor = "Graciliano Ramos", Ano = 1938, Disponivel = true },
new Livro { Id = 5, Titulo = "A Hora da Estrela", Autor = "Clarice Lispector", Ano = 1977, Disponivel = false },
new Livro { Id = 6, Titulo = "Memórias Póstumas", Autor = "Machado de Assis", Ano = 1881, Disponivel = true },
new Livro { Id = 7, Titulo = "Iracema", Autor = "José de Alencar", Ano = 1865, Disponivel = true },
new Livro { Id = 8, Titulo = "O Alienista", Autor = "Machado de Assis", Ano = 1882, Disponivel = false },
new Livro { Id = 9, Titulo = "Grande Sertão", Autor = "Guimarães Rosa", Ano = 1956, Disponivel = true },
new Livro { Id = 10, Titulo = "Quincas Borba", Autor = "Machado de Assis", Ano = 1891, Disponivel = false } };
    private static string Situacao(Livro x) => "";
public IActionResult Index() => View(Itens);
public IActionResult Disponiveis() => View(Itens.Where(x=>x.Disponivel));

}
