using Microsoft.AspNetCore.Mvc;
namespace EletronicosMVC.Controllers;
public class HomeController : Controller {
    public IActionResult Index() => RedirectToAction("Index", "Eletronicos");
}
