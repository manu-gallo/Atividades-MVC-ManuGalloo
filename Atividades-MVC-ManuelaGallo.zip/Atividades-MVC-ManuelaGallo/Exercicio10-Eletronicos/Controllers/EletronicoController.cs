using Microsoft.AspNetCore.Mvc;
using EletronicosMVC.Models;
namespace EletronicosMVC.Controllers;
public class EletronicoController : Controller {
    private static readonly List<Eletronico> Itens = new() { new Eletronico { Id = 1, Nome = "Notebook", Marca = "Dell", Categoria = "Informática", Preco = 3500m, Estoque = 5 },
new Eletronico { Id = 2, Nome = "Celular", Marca = "Samsung", Categoria = "Celulares", Preco = 2200m, Estoque = 8 },
new Eletronico { Id = 3, Nome = "TV 50", Marca = "LG", Categoria = "Televisores", Preco = 2800m, Estoque = 2 },
new Eletronico { Id = 4, Nome = "Fone", Marca = "JBL", Categoria = "Áudio", Preco = 450m, Estoque = 0 },
new Eletronico { Id = 5, Nome = "Tablet", Marca = "Lenovo", Categoria = "Informática", Preco = 1200m, Estoque = 4 },
new Eletronico { Id = 6, Nome = "Smartwatch", Marca = "Apple", Categoria = "Wearables", Preco = 2500m, Estoque = 3 },
new Eletronico { Id = 7, Nome = "Monitor", Marca = "AOC", Categoria = "Informática", Preco = 900m, Estoque = 6 },
new Eletronico { Id = 8, Nome = "Console", Marca = "Sony", Categoria = "Games", Preco = 4200m, Estoque = 0 },
new Eletronico { Id = 9, Nome = "Teclado", Marca = "Logitech", Categoria = "Periféricos", Preco = 250m, Estoque = 12 },
new Eletronico { Id = 10, Nome = "Mouse", Marca = "Logitech", Categoria = "Periféricos", Preco = 120m, Estoque = 15 },
new Eletronico { Id = 11, Nome = "Soundbar", Marca = "Samsung", Categoria = "Áudio", Preco = 1100m, Estoque = 1 },
new Eletronico { Id = 12, Nome = "Câmera", Marca = "Canon", Categoria = "Câmeras", Preco = 3200m, Estoque = 2 } };
    private static string Situacao(Eletronico x) => "";
public IActionResult Index() => View(Itens);
public IActionResult EmEstoque() => View(Itens.Where(x=>x.Estoque>0));
public IActionResult Categoria() => View(Itens.Where(x=>x.Categoria=="Informática"));
public IActionResult Baratos() => View(Itens.Where(x=>x.Preco<1000));

}
