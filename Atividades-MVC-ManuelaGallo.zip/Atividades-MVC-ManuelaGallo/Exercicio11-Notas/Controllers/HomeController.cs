using Microsoft.AspNetCore.Mvc;
namespace NotasMVC.Controllers;
public class HomeController : Controller {
    public IActionResult Index() => RedirectToAction("Index", "Notas");
}
