using Microsoft.AspNetCore.Mvc;
using NotasMVC.Models;
namespace NotasMVC.Controllers;
public class AlunoController : Controller {
    private static readonly List<Aluno> Itens = new() { new Aluno { Id = 1, Nome = "Ana", Curso = "DS", Nota1 = 8, Nota2 = 7, Nota3 = 9 },
new Aluno { Id = 2, Nome = "Bruno", Curso = "ADM", Nota1 = 5, Nota2 = 6, Nota3 = 5 },
new Aluno { Id = 3, Nome = "Carla", Curso = "Eletrônica", Nota1 = 3, Nota2 = 4, Nota3 = 2 },
new Aluno { Id = 4, Nome = "Diego", Curso = "DS", Nota1 = 9, Nota2 = 8, Nota3 = 10 },
new Aluno { Id = 5, Nome = "Elisa", Curso = "ADM", Nota1 = 6, Nota2 = 6, Nota3 = 6 },
new Aluno { Id = 6, Nome = "Felipe", Curso = "Mecânica", Nota1 = 4, Nota2 = 5, Nota3 = 4 },
new Aluno { Id = 7, Nome = "Giovana", Curso = "DS", Nota1 = 7, Nota2 = 8, Nota3 = 7 },
new Aluno { Id = 8, Nome = "Henrique", Curso = "Eletrônica", Nota1 = 2, Nota2 = 3, Nota3 = 3 },
new Aluno { Id = 9, Nome = "Isabela", Curso = "ADM", Nota1 = 10, Nota2 = 9, Nota3 = 9 },
new Aluno { Id = 10, Nome = "João", Curso = "Mecânica", Nota1 = 5, Nota2 = 5, Nota3 = 6 } };
    private static string Situacao(Aluno x) => "";
public IActionResult Index() => View(Itens);
public IActionResult Aprovados() => View(Itens.Where(x=>(x.Nota1+x.Nota2+x.Nota3)/3>=6));
public IActionResult Recuperacao() => View(Itens.Where(x=>(x.Nota1+x.Nota2+x.Nota3)/3>=4 && (x.Nota1+x.Nota2+x.Nota3)/3<6));
public IActionResult Reprovados() => View(Itens.Where(x=>(x.Nota1+x.Nota2+x.Nota3)/3<4));
private static double Media(Aluno x) => (x.Nota1+x.Nota2+x.Nota3)/3.0;
private static string Situacao(Aluno x) => Media(x)>=6 ? "Aprovado" : Media(x)>=4 ? "Recuperação" : "Reprovado";
public IActionResult Aprovados() => View(Itens.Where(x=>Media(x)>=6));
public IActionResult Recuperacao() => View(Itens.Where(x=>Media(x)>=4 && Media(x)<6));
public IActionResult Reprovados() => View(Itens.Where(x=>Media(x)<4));
}
