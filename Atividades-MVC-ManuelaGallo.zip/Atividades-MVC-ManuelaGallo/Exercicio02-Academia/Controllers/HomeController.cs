using Microsoft.AspNetCore.Mvc;
namespace AcademiaMVC.Controllers;
public class HomeController : Controller { public IActionResult Index() => RedirectToAction("Index", "Academia"); }
