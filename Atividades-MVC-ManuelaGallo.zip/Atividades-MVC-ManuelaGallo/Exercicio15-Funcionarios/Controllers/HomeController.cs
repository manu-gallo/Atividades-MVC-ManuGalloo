using Microsoft.AspNetCore.Mvc;
namespace FuncionariosMVC.Controllers;
public class HomeController : Controller {
    public IActionResult Index() => RedirectToAction("Index", "Funcionarios");
}
