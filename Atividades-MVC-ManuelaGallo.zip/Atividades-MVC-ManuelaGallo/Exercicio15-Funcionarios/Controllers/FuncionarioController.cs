using Microsoft.AspNetCore.Mvc;
using FuncionariosMVC.Models;
namespace FuncionariosMVC.Controllers;
public class FuncionarioController : Controller {
    private static readonly List<Funcionario> Itens = new() { new Funcionario { Id = 1, Nome = "Ana", Cargo = "Analista", Departamento = "TI", Salario = 4200m, Ativo = true },
new Funcionario { Id = 2, Nome = "Bruno", Cargo = "Técnico", Departamento = "Manutenção", Salario = 2800m, Ativo = true },
new Funcionario { Id = 3, Nome = "Carla", Cargo = "Gerente", Departamento = "RH", Salario = 7500m, Ativo = true },
new Funcionario { Id = 4, Nome = "Diego", Cargo = "Assistente", Departamento = "Financeiro", Salario = 2200m, Ativo = false },
new Funcionario { Id = 5, Nome = "Elisa", Cargo = "Desenvolvedora", Departamento = "TI", Salario = 5800m, Ativo = true },
new Funcionario { Id = 6, Nome = "Felipe", Cargo = "Técnico", Departamento = "Produção", Salario = 3100m, Ativo = true },
new Funcionario { Id = 7, Nome = "Giovana", Cargo = "Coordenadora", Departamento = "RH", Salario = 5200m, Ativo = true },
new Funcionario { Id = 8, Nome = "Henrique", Cargo = "Auxiliar", Departamento = "Financeiro", Salario = 2300m, Ativo = false },
new Funcionario { Id = 9, Nome = "Isabela", Cargo = "Analista", Departamento = "TI", Salario = 4700m, Ativo = true },
new Funcionario { Id = 10, Nome = "João", Cargo = "Supervisor", Departamento = "Produção", Salario = 4900m, Ativo = true },
new Funcionario { Id = 11, Nome = "Karen", Cargo = "Assistente", Departamento = "RH", Salario = 2400m, Ativo = true },
new Funcionario { Id = 12, Nome = "Lucas", Cargo = "Analista", Departamento = "Financeiro", Salario = 3900m, Ativo = true },
new Funcionario { Id = 13, Nome = "Marina", Cargo = "Gerente", Departamento = "TI", Salario = 9000m, Ativo = true },
new Funcionario { Id = 14, Nome = "Nicolas", Cargo = "Auxiliar", Departamento = "Produção", Salario = 2100m, Ativo = false },
new Funcionario { Id = 15, Nome = "Olivia", Cargo = "Coordenadora", Departamento = "Financeiro", Salario = 6100m, Ativo = true } };
    private static string Situacao(Funcionario x) => "";
public IActionResult Index() => View(Itens);
public IActionResult Ativos() => View(Itens.Where(x=>x.Ativo));
public IActionResult Inativos() => View(Itens.Where(x=>!x.Ativo));
public IActionResult Departamento() => View(Itens.Where(x=>x.Departamento=="TI"));
public IActionResult Dashboard() => View(Itens);
public IActionResult Ativos() => View(Itens.Where(x=>x.Ativo));
public IActionResult Inativos() => View(Itens.Where(x=>!x.Ativo));
public IActionResult Departamento(string nome="TI") => View(Itens.Where(x=>x.Departamento==nome));
public IActionResult Dashboard() => View(Itens);
}
