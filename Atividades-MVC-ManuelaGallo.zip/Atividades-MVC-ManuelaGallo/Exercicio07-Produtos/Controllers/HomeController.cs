using Microsoft.AspNetCore.Mvc;
namespace ProdutosMVC.Controllers;
public class HomeController : Controller {
    public IActionResult Index() => RedirectToAction("Index", "Produtos");
}
