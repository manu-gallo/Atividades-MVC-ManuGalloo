using Microsoft.AspNetCore.Mvc;
using ProdutosMVC.Models;
namespace ProdutosMVC.Controllers;
public class ProdutoController : Controller {
    private static readonly List<Produto> Itens = new() { new Produto { Id = 1, Nome = "Notebook", Categoria = "Eletrônicos", Estoque = 5, Preco = 3500m },
new Produto { Id = 2, Nome = "Mouse", Categoria = "Periféricos", Estoque = 0, Preco = 80m },
new Produto { Id = 3, Nome = "Teclado", Categoria = "Periféricos", Estoque = 12, Preco = 150m },
new Produto { Id = 4, Nome = "Monitor", Categoria = "Eletrônicos", Estoque = 3, Preco = 900m },
new Produto { Id = 5, Nome = "Fone", Categoria = "Áudio", Estoque = 8, Preco = 220m },
new Produto { Id = 6, Nome = "Webcam", Categoria = "Acessórios", Estoque = 0, Preco = 180m },
new Produto { Id = 7, Nome = "SSD", Categoria = "Armazenamento", Estoque = 7, Preco = 450m },
new Produto { Id = 8, Nome = "Pendrive", Categoria = "Armazenamento", Estoque = 20, Preco = 60m },
new Produto { Id = 9, Nome = "Impressora", Categoria = "Eletrônicos", Estoque = 2, Preco = 780m },
new Produto { Id = 10, Nome = "Caixa de som", Categoria = "Áudio", Estoque = 4, Preco = 300m } };
    private static string Situacao(Produto x) => "";
public IActionResult Index() => View(Itens);
public IActionResult Disponiveis() => View(Itens.Where(x=>x.Estoque>0));

}
