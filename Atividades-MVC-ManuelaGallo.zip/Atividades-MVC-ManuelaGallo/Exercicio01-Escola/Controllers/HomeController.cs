using Microsoft.AspNetCore.Mvc;
namespace EscolaMVC.Controllers;
public class HomeController : Controller { public IActionResult Index() => RedirectToAction("Index", "Escola"); }
