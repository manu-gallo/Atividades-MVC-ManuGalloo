using Microsoft.AspNetCore.Mvc;
using VeterinariaMVC.Models;
namespace VeterinariaMVC.Controllers;
public class VeterinariaController : Controller {
    private static readonly List<Animal> Itens = new() { new Animal { Id = 1, Nome = "Rex", Especie = "Cachorro", Idade = 4, Dono = "Manuela" },
new Animal { Id = 2, Nome = "Luna", Especie = "Gato", Idade = 2, Dono = "Ana" },
new Animal { Id = 3, Nome = "Thor", Especie = "Cachorro", Idade = 6, Dono = "Bruno" },
new Animal { Id = 4, Nome = "Mia", Especie = "Gato", Idade = 3, Dono = "Carla" },
new Animal { Id = 5, Nome = "Mel", Especie = "Cachorro", Idade = 1, Dono = "Diego" },
new Animal { Id = 6, Nome = "Nina", Especie = "Gato", Idade = 5, Dono = "Elisa" },
new Animal { Id = 7, Nome = "Bob", Especie = "Cachorro", Idade = 7, Dono = "Felipe" },
new Animal { Id = 8, Nome = "Pipoca", Especie = "Gato", Idade = 2, Dono = "Giovana" } };
    private static string Situacao(Animal x) => "";
public IActionResult Index() => View(Itens);
public IActionResult Cachorros() => View(Itens.Where(x=>x.Especie=="Cachorro"));
public IActionResult Gatos() => View(Itens.Where(x=>x.Especie=="Gato"));

}
