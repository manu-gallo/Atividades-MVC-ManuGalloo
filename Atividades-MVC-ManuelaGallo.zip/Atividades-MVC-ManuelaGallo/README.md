# Atividades ASP.NET Core MVC
**Aluno:** Manuela Gallo  
**Turma:** __________

## Exercícios
01 - Escola
02 - Academia
03 - Cinema
04 - Restaurante
05 - Hotel
06 - Cadastro de Alunos
07 - Catálogo de Produtos
08 - Biblioteca
09 - Clínica Veterinária
10 - Loja de Eletrônicos
11 - Sistema de Notas
12 - Sistema de Estoque
13 - Sistema de Pedidos
14 - Sistema de Cursos
15 - Sistema de Cadastro de Funcionários

## Como executar
Abra a pasta do exercício no Visual Studio e execute o projeto `.csproj`.
Os projetos utilizam ASP.NET Core MVC, C# e dados em memória, conforme solicitado na atividade.

> Antes da entrega, execute e teste cada projeto no Visual Studio e adicione imagens reais da aplicação ao README, conforme a orientação do professor.
