using Microsoft.AspNetCore.Mvc;
using PedidosMVC.Models;
namespace PedidosMVC.Controllers;
public class PedidoController : Controller {
    private static readonly List<Pedido> Itens = new() { new Pedido { Id = 1, Cliente = "Ana", Produto = "X-Burger", Quantidade = 2, PrecoUnitario = 22m, Status = "Recebido" },
new Pedido { Id = 2, Cliente = "Bruno", Produto = "Batata", Quantidade = 1, PrecoUnitario = 15m, Status = "Em preparo" },
new Pedido { Id = 3, Cliente = "Carla", Produto = "X-Salada", Quantidade = 2, PrecoUnitario = 24m, Status = "Pronto" },
new Pedido { Id = 4, Cliente = "Diego", Produto = "Suco", Quantidade = 3, PrecoUnitario = 8m, Status = "Entregue" },
new Pedido { Id = 5, Cliente = "Elisa", Produto = "Pizza", Quantidade = 1, PrecoUnitario = 40m, Status = "Em preparo" },
new Pedido { Id = 6, Cliente = "Felipe", Produto = "X-Burger", Quantidade = 1, PrecoUnitario = 22m, Status = "Pronto" },
new Pedido { Id = 7, Cliente = "Giovana", Produto = "Batata", Quantidade = 2, PrecoUnitario = 15m, Status = "Entregue" },
new Pedido { Id = 8, Cliente = "Henrique", Produto = "Pizza", Quantidade = 2, PrecoUnitario = 40m, Status = "Recebido" },
new Pedido { Id = 9, Cliente = "Isabela", Produto = "Suco", Quantidade = 2, PrecoUnitario = 8m, Status = "Em preparo" },
new Pedido { Id = 10, Cliente = "João", Produto = "X-Salada", Quantidade = 1, PrecoUnitario = 24m, Status = "Entregue" } };
    private static string Situacao(Pedido x) => "";
public IActionResult Index() => View(Itens);
public IActionResult EmPreparo() => View(Itens.Where(x=>x.Status=="Em preparo"));
public IActionResult Prontos() => View(Itens.Where(x=>x.Status=="Pronto"));
public IActionResult Entregues() => View(Itens.Where(x=>x.Status=="Entregue"));

}
