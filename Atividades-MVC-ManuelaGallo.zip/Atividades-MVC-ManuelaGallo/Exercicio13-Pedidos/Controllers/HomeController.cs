using Microsoft.AspNetCore.Mvc;
namespace PedidosMVC.Controllers;
public class HomeController : Controller {
    public IActionResult Index() => RedirectToAction("Index", "Pedidos");
}
