using Microsoft.AspNetCore.Mvc;
using EstoqueMVC.Models;
namespace EstoqueMVC.Controllers;
public class EstoqueController : Controller {
    private static readonly List<Produto> Itens = new() { new Produto { Id = 1, Nome = "Arroz", Categoria = "Alimentos", Estoque = 0, EstoqueMinimo = 5, Preco = 25m },
new Produto { Id = 2, Nome = "Feijão", Categoria = "Alimentos", Estoque = 3, EstoqueMinimo = 5, Preco = 10m },
new Produto { Id = 3, Nome = "Caderno", Categoria = "Papelaria", Estoque = 20, EstoqueMinimo = 10, Preco = 15m },
new Produto { Id = 4, Nome = "Caneta", Categoria = "Papelaria", Estoque = 4, EstoqueMinimo = 10, Preco = 3m },
new Produto { Id = 5, Nome = "Sabonete", Categoria = "Higiene", Estoque = 15, EstoqueMinimo = 5, Preco = 4m },
new Produto { Id = 6, Nome = "Shampoo", Categoria = "Higiene", Estoque = 0, EstoqueMinimo = 4, Preco = 18m },
new Produto { Id = 7, Nome = "Café", Categoria = "Alimentos", Estoque = 8, EstoqueMinimo = 6, Preco = 20m },
new Produto { Id = 8, Nome = "Açúcar", Categoria = "Alimentos", Estoque = 2, EstoqueMinimo = 5, Preco = 6m },
new Produto { Id = 9, Nome = "Detergente", Categoria = "Limpeza", Estoque = 12, EstoqueMinimo = 5, Preco = 4m },
new Produto { Id = 10, Nome = "Papel", Categoria = "Papelaria", Estoque = 30, EstoqueMinimo = 10, Preco = 8m },
new Produto { Id = 11, Nome = "Esponja", Categoria = "Limpeza", Estoque = 0, EstoqueMinimo = 4, Preco = 3m },
new Produto { Id = 12, Nome = "Leite", Categoria = "Alimentos", Estoque = 5, EstoqueMinimo = 5, Preco = 6m },
new Produto { Id = 13, Nome = "Biscoito", Categoria = "Alimentos", Estoque = 1, EstoqueMinimo = 5, Preco = 7m },
new Produto { Id = 14, Nome = "Pasta", Categoria = "Papelaria", Estoque = 9, EstoqueMinimo = 5, Preco = 12m },
new Produto { Id = 15, Nome = "Desinfetante", Categoria = "Limpeza", Estoque = 3, EstoqueMinimo = 5, Preco = 14m } };
    private static string Situacao(Produto x) => "";
public IActionResult Index() => View(Itens);
public IActionResult Baixo() => View(Itens.Where(x=>x.Estoque>0 && x.Estoque<=x.EstoqueMinimo));
public IActionResult Esgotados() => View(Itens.Where(x=>x.Estoque==0));
public IActionResult Alertas() => View(Itens.Where(x=>x.Estoque<=x.EstoqueMinimo));

}
