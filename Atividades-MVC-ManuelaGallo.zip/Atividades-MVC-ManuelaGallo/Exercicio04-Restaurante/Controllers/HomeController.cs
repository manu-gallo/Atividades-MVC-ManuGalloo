using Microsoft.AspNetCore.Mvc;
namespace RestauranteMVC.Controllers;
public class HomeController : Controller { public IActionResult Index() => RedirectToAction("Index", "Restaurante"); }
