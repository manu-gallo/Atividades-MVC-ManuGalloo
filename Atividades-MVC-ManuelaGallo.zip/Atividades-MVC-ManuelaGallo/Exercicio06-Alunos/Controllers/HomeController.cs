using Microsoft.AspNetCore.Mvc;
namespace AlunosMVC.Controllers;
public class HomeController : Controller {
    public IActionResult Index() => RedirectToAction("Index", "Alunos");
}
