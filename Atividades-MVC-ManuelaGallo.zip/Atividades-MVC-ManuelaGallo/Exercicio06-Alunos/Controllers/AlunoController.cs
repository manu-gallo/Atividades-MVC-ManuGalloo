using Microsoft.AspNetCore.Mvc;
using AlunosMVC.Models;
namespace AlunosMVC.Controllers;
public class AlunoController : Controller {
    private static readonly List<Aluno> Itens = new() { new Aluno { Id = 1, Nome = "Ana", Idade = 16, Curso = "Desenvolvimento" },
new Aluno { Id = 2, Nome = "Bruno", Idade = 17, Curso = "Administração" },
new Aluno { Id = 3, Nome = "Carla", Idade = 15, Curso = "Eletrônica" },
new Aluno { Id = 4, Nome = "Diego", Idade = 18, Curso = "Mecânica" },
new Aluno { Id = 5, Nome = "Elisa", Idade = 16, Curso = "Desenvolvimento" },
new Aluno { Id = 6, Nome = "Felipe", Idade = 17, Curso = "Administração" },
new Aluno { Id = 7, Nome = "Giovana", Idade = 15, Curso = "Eletrônica" },
new Aluno { Id = 8, Nome = "Henrique", Idade = 18, Curso = "Mecânica" } };
    private static string Situacao(Aluno x) => "";
public IActionResult Index() => View(Itens);
public IActionResult Detalhes() => View(Itens.Take(1));

}
