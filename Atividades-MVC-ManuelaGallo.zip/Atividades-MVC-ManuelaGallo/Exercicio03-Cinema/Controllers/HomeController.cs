using Microsoft.AspNetCore.Mvc;
namespace CinemaMVC.Controllers;
public class HomeController : Controller { public IActionResult Index() => RedirectToAction("Index", "Cinema"); }
