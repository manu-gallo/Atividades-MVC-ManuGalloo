using Microsoft.AspNetCore.Mvc;
using CursosMVC.Models;
namespace CursosMVC.Controllers;
public class CursoController : Controller {
    private static readonly List<Curso> Itens = new() { new Curso { Id = 1, Nome = "C#", CargaHoraria = "120h", Modalidade = "Online", Vagas = 20, Valor = 800m },
new Curso { Id = 2, Nome = "HTML e CSS", CargaHoraria = "80h", Modalidade = "Online", Vagas = 0, Valor = 500m },
new Curso { Id = 3, Nome = "Banco de Dados", CargaHoraria = "100h", Modalidade = "Presencial", Vagas = 15, Valor = 650m },
new Curso { Id = 4, Nome = "JavaScript", CargaHoraria = "120h", Modalidade = "Online", Vagas = 10, Valor = 900m },
new Curso { Id = 5, Nome = "Redes", CargaHoraria = "80h", Modalidade = "Presencial", Vagas = 0, Valor = 600m },
new Curso { Id = 6, Nome = "Python", CargaHoraria = "120h", Modalidade = "Online", Vagas = 25, Valor = 850m },
new Curso { Id = 7, Nome = "Robótica", CargaHoraria = "160h", Modalidade = "Presencial", Vagas = 12, Valor = 1200m },
new Curso { Id = 8, Nome = "UX/UI", CargaHoraria = "80h", Modalidade = "Online", Vagas = 8, Valor = 700m },
new Curso { Id = 9, Nome = "Excel", CargaHoraria = "40h", Modalidade = "Presencial", Vagas = 30, Valor = 350m },
new Curso { Id = 10, Nome = "Gestão", CargaHoraria = "60h", Modalidade = "Presencial", Vagas = 0, Valor = 450m } };
    private static string Situacao(Curso x) => "";
public IActionResult Index() => View(Itens);
public IActionResult Disponiveis() => View(Itens.Where(x=>x.Vagas>0));
public IActionResult Online() => View(Itens.Where(x=>x.Modalidade=="Online"));
public IActionResult Presenciais() => View(Itens.Where(x=>x.Modalidade=="Presencial"));

}
