using Microsoft.AspNetCore.Mvc;
namespace CursosMVC.Controllers;
public class HomeController : Controller {
    public IActionResult Index() => RedirectToAction("Index", "Cursos");
}
